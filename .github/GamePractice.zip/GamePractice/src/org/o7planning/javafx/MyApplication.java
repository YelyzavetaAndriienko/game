package org.o7planning.javafx;
 
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ColorPicker;
import javafx.scene.effect.InnerShadow;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
 
public class MyApplication extends Application {
    
  
    @Override
    public void start(Stage primaryStage) {
        try {
            Parent root = FXMLLoader.load(getClass()
                    .getResource("/org/o7planning/javafx/MyScene.fxml"));
            root.setStyle("-fx-background-color: #D7FFF9");
            
            
            primaryStage.setTitle("PAC-MAN");
            primaryStage.setScene(new Scene(root));
            primaryStage.show();
            
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
         public static void main(String args[]){ 
            launch(args); 
         } 
    }
     // root.setStyle("-fx-background-color: #E7FFCE");
     // root.setStyle("-fx-background-color: #D7FFF9");
     // root.setStyle("-fx-background-color: #02FFD5"); 
     // root.setStyle("-fx-background-color: #A5FD78");
/*
 * final ColorPicker colorPicker = new ColorPicker();
            final Polygon poly = new Polygon();
            poly.getPoints().addAll(new Double[]{        
            		   0.0, 585.0, 
            		   0.0, 565.0, 
            		   20.0, 545.0,          
            		   40.0, 545.0, 
            		   60.0, 565.0,                   
            		   40.0, 575.0,
            		   60.0, 585.0, 
            		   40.0, 605.0, 
            		   20.0, 605.0,     
            		});
         
            poly.setFill(colorPicker.getValue());
            colorPicker.setOnAction(new EventHandler<ActionEvent>() {
            	 
                public void handle(ActionEvent event) {
                    poly.setFill(colorPicker.getValue());
                }
            });
     
 */
/*
 *   <ColorPicker fx:id="colorButton" layoutX="510.0" layoutY="10.0" prefHeight="30.0" prefWidth="100.0">
         <effect>
            <DropShadow />
         </effect></ColorPicker>
      
 */
           