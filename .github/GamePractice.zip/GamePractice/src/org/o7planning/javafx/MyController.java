package org.o7planning.javafx;
 
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import com.sun.javafx.geom.Rectangle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.shape.Polygon;
 
public class MyController implements Initializable {
 
   @FXML
   private Button pauseButton;
   @FXML
   private Button restartButton;
   @FXML
   private Button instructionButton;
   @FXML
   private ColorPicker colorButton;
   @FXML
   private Label levelLabel;
   @FXML
   private Label heartLabel;
   @FXML
   private Polygon poly;
   
   
  
   @Override
   public void initialize(URL location, ResourceBundle resources) {
	   pauseButton.setStyle("-fx-background-color: #FED8D8");
	   restartButton.setStyle("-fx-background-color: #CEE7FF");
	   instructionButton.setStyle("-fx-background-color: #CEFCE3");
	   colorButton.setStyle("-fx-background-color: #FBFCCE");
	   poly.setFill(colorButton.getValue());
	   colorButton.setOnAction(new EventHandler<ActionEvent>() {
       	 
           public void handle(ActionEvent event) {
               poly.setFill(colorButton.getValue());
           }
       });
   }
   
   public void pause(ActionEvent event) {
   // pauseButton.setStyle("-fx-background-color: #FED8D8");
   }
   
   public void restart(ActionEvent event) {
	    
   }

   public void instruction(ActionEvent event) {
	    
   }
  
}