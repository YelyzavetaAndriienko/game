package view;



import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.PacManButton;
import model.PacManSubscene;

public class ViewManager {

	private final static int HEIGHT = 600;
	private final static int WIDTH = 800;
	private AnchorPane mainPane;
	private Scene mainScene;
	private Stage mainStage;
	private final static int MENU_BUTTONS_START_X = 100;
	private final static int MENU_BUTTONS_START_Y = 150;
	private PacManSubscene startSubscene;
	private PacManSubscene helpSubscene;
	private PacManSubscene creditsSubscene;
	private PacManSubscene exitSubscene;
	private PacManSubscene sceneToHide;
	List<PacManButton> menuButtons;
	
	public ViewManager() {
		menuButtons = new ArrayList<>();
		mainPane = new AnchorPane();
		mainScene = new Scene(mainPane, WIDTH, HEIGHT);
		mainStage = new Stage();
		mainStage.setScene(mainScene);
		createSubscenes();
		createButtons();
		createLogo();
		createBackground();
		}
	
    public Stage getMainStage() {
    	return mainStage;
    }
    
    private void showSubscene(PacManSubscene subscene) {
    	if(sceneToHide != null) {
    		sceneToHide.moveSubscene();
    	}
    	subscene.moveSubscene();
    	sceneToHide = subscene;
    }
    
    private void createSubscenes() {
    	
    	helpSubscene = new PacManSubscene();
    	mainPane.getChildren().add(helpSubscene);
    	
    	creditsSubscene = new PacManSubscene();
    	mainPane.getChildren().add(creditsSubscene);
    	
    	exitSubscene = new PacManSubscene();
    	mainPane.getChildren().add(exitSubscene);
   
        createStartSubscene();
    }
    
    private void addMenuButton(PacManButton button) {
    	button.setLayoutX(MENU_BUTTONS_START_X);
    	button.setLayoutY(MENU_BUTTONS_START_Y + menuButtons.size() * 100);
    	menuButtons.add(button);
    	mainPane.getChildren().add(button);
    }
    
    private void createButtons() {
    	createStartButton();
    	createHelpButton();
    	createCreditsButton();
    	createExitButton();
    }
    
    private void createStartSubscene() {
    	startSubscene = new PacManSubscene();
    	mainPane.getChildren().add(startSubscene);
    	startSubscene.getPane().getChildren().add(createButtonToStart());
    }
    
    private PacManButton createButtonToStart() {
    	PacManButton startButton = new PacManButton("START");
    	startButton.setLayoutX(200);
    	startButton.setLayoutY(300);
    	startButton.setOnAction(new EventHandler<ActionEvent>() {
    		@Override
    		public void handle(ActionEvent event) {
    			GameViewManager gameManager = new GameViewManager();
    			gameManager.createNewGame(mainStage);
    	}
    	});
    	return startButton;
    }
    
    private void createStartButton() {
    	PacManButton startButton = new PacManButton("PLAY");
    	addMenuButton(startButton);
    	startButton.setOnAction(new EventHandler<ActionEvent>() {
    		@Override
    		public void handle(ActionEvent event) {
    			showSubscene(startSubscene);
    		}	
    	});
    }
    
    private void createHelpButton() {
    	PacManButton helpButton = new PacManButton("HELP");
    	addMenuButton(helpButton);
    	helpButton.setOnAction(new EventHandler<ActionEvent>() {
    		@Override
    		public void handle(ActionEvent event) {
    			showSubscene(helpSubscene);
    		}	
    	});
    }
    
    private void createCreditsButton() {
    	PacManButton creditsButton = new PacManButton("CREDITS");
    	addMenuButton(creditsButton);
    	creditsButton.setOnAction(new EventHandler<ActionEvent>() {
    		@Override
    		public void handle(ActionEvent event) {
    			showSubscene(creditsSubscene);
    		}	
    	});
    }
    
    private void createExitButton() {
    	PacManButton exitButton = new PacManButton("EXIT");
    	addMenuButton(exitButton);
    	exitButton.setOnAction(new EventHandler<ActionEvent>() {
    		@Override
    		public void handle(ActionEvent event) {
    			mainStage.close();
    		}	
    	});
    }
    
    private void createBackground() {
    	Image backgroundImage = new Image("view/resources/fon2.gif", 256, 256, false, true);
    	BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, null);
    	mainPane.setBackground(new Background(background));
    }
    
    private void createLogo() {
        Image image = new Image("view/resources/label7.png");
    	ImageView img = new ImageView(image);
    	img.setLayoutX(350);
    	img.setLayoutY(20);
    	
    	img.setOnMouseEntered(new EventHandler<MouseEvent>() {
    		@Override
    		public void handle(MouseEvent event) {
    			DropShadow d = new DropShadow();
    			d.setColor(Color.WHITE);
    			img.setEffect(d);
    		}
    	});
		
    	img.setOnMouseExited(new EventHandler<MouseEvent>() {
    		@Override
    		public void handle(MouseEvent event) {
    			img.setEffect(null);
    		}
    	});
    	mainPane.getChildren().add(img);
    }
}